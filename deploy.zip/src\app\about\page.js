import AboutPage from '@/components/AboutPage/AboutPage';

export default function About() {
	return (
		<div>
			<AboutPage />
		</div>
	);
}

