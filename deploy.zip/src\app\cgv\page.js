import CgvFullPage from '@/components/legal/CgvFullPage/CgvFullPage';

export default function CgvFull() {
	return (
		<div className='container'>
			<CgvFullPage />
		</div>
	);
}
