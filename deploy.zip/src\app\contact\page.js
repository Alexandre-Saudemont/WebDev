import ContactPage from '@/components/ContactPage/ContactPage';

export default function Contact() {
	return (
		<div>
			<ContactPage />
		</div>
	);
}

