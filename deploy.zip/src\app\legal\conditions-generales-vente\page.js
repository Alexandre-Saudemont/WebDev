import CgvPage from '@/components/Legal/CgvPage/CgvPage';

export default function CGV() {
	return (
		<div>
			<CgvPage />
		</div>
	);
}

