import MentionsPage from '@/components/Legal/MentionsPage/MentionsPage';

export default function Mentions() {
	return (
		<div>
			<MentionsPage />
		</div>
	);
}

