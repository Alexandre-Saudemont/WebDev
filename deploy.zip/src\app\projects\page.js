import ProjectsPage from '@/components/Projects/ProjectsPage';

export default function Projects() {
	return (
		<div>
			<ProjectsPage />
		</div>
	);
}

