import ServicesPage from '@/components/ServicesPage/ServicesPage';

export default function Services() {
	return (
		<div>
			<ServicesPage />
		</div>
	);
}

