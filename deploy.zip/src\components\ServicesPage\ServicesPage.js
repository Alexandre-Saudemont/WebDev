'use client';

import {useMemo} from 'react';
import {useTranslation} from 'react-i18next';
import ServicesHeader from './ServicesHeader/ServicesHeader';
import ServicesGrid from './ServicesGrid/ServicesGrid';
import ServicesCta from './ServicesCta/ServicesCta';
import './ServicesPage.css';

export default function ServicesPage() {
	const {t} = useTranslation();

	const services = useMemo(() => {
		try {
			const data = t('services.items', {returnObjects: true});
			return data || [];
		} catch (error) {
			console.error('Erreur i18n:', error);
			return [];
		}
	}, [t]);

	return (
		<div className='services-page'>
			<ServicesHeader />
			<ServicesGrid services={services} />
			<ServicesCta />
		</div>
	);
}
